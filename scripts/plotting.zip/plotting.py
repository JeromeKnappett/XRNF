#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 25 14:27:21 2022

@author: jerome
"""

import numpy as np
import matplotlib.pyplot as plt
import imageio
import tifffile
import pickle

colours = plt.rcParams["axes.prop_cycle"].by_key()["color"]

def round_sig(x, sig=2):
    from math import floor, log10
    if x != 0:
        return round(x, sig-int(floor(log10(abs(x))))-1)
    else:
        return x

def plotTwoD(t, dx=1, dy=1, sF=1, describe=False, title=None, xLabel=None, yLabel=None, colour=None, cbarLabel=None, aspct='auto', savePath=None):
    nx, ny = np.shape(t)[1], np.shape(t)[0]
    midX, midY = nx/2, ny/2
    rx, ry = nx*dx, ny*dy
    
    if describe:
        print(title)
        print("Shape of tif (x,y): ", (nx,ny))
        print("Range (x,y): {}".format((rx,ry)))
        print("Resolution (x,y): {}".format((dx,dy)))
    else:
        pass
    
    plt.imshow(t, cmap=colour, aspect=aspct)
    plt.yticks([int(ny*(b/8)) for b in range(0,9)],
               [round_sig(ny*dy*(a/8)*sF) for a in range(-4,5)],fontsize=10 )
    plt.xticks([int(nx*(b/8)) for b in range(0,9)],
               [round_sig(nx*dx*(a/8)*sF) for a in range(-4,5)],fontsize=10 )
    plt.colorbar(label=cbarLabel).ax.tick_params(labelsize=10)
    plt.xlabel(xLabel,fontsize=15 )#[\u03bcm]')
    plt.ylabel(yLabel,fontsize=15 )#[\u03bcm]')
    plt.title(label=title)
    plt.tight_layout()
    if savePath != None:
        print("Saving : ", savePath)
        plt.savefig(savePath)
    plt.show()
    
def plotOneD(p, d=1, sF=1, describe=False, split=None, title=None, labels=None, xLabel=None, yLabel=None, aspct='auto', savePath=None):
    n, x = int(np.shape(p)[0]), int(np.shape(p)[1])
    mid = x/2
    r = x*d
    
    if describe:
        print(title)
        print("Number of profiles (n): ", n)
        print("Length of profiles (x): ", x)
        print("Range [m]: {}".format(r))
        print("Resolution [m]: {}".format(d))
    else:
        pass
    
    if title == None:
        title = np.full(n, None)
    elif labels == None:
        labels = np.full(n, None)
    elif xLabel == None:
        xLabel = np.full(n, None)
    elif yLabel == None:
        yLabel = np.full(n, None)
    else:
        pass
    
    print(title)
    print(labels)
    print(xLabel)
    print(yLabel)
    
    plt.gca().set_aspect(aspct)
    if split != None:
        if split == 'columns':
            fig, ax = plt.subplots(1,n)
        elif split == 'rows':
            fig, ax = plt.subplots(n,1)
        
        for i, l in enumerate(p):
            ax[i].plot(l, label=labels[i])
            ax[i].set_title(label=title[i])
            ax[i].set_xlabel(xLabel, fontsize=10)
            ax[i].set_ylabel(yLabel, fontsize=10)
            ax[i].legend()
            ax[i].set_xticks([int(x*(b/6)) for b in range(0,7)])
            ax[i].set_xticklabels([round_sig(x*d*(a/6)*sF) for a in range(-3,4)],fontsize=10 )
    else:
        for i, l in enumerate(p):
            plt.plot(l, label=labels[i])
            plt.xlabel(xLabel,fontsize=15 )#[\u03bcm]')
            plt.ylabel(yLabel,fontsize=15 )#[\u03bcm]')
            plt.title(label=title[0])
            plt.tight_layout()
            plt.xticks([int(x*(b/8)) for b in range(0,9)],
                       [round_sig(x*d*(a/8)*sF) for a in range(-4,5)],fontsize=10 )
        plt.legend()
#    plt.tight_layout()
    if savePath != None:
        print("Saving : ", savePath)
        plt.savefig(savePath)
    plt.show()
    
def resample(a,fx,fy, debug = False):
    nx, ny = np.shape(a)[1], np.shape(a)[0]
    midX, midY = nx/2, ny/2
    aNew = a[int(midY-fy*midY):int(midY+fy*midY), int(midX-fx*midX):int(midX+fx*midX)]
    if debug:
        print("original shape: ", np.shape(a))
        print("new shape: ", np.shape(aNew))
    else:
        pass
    return aNew

def testPlot2D():
    dirPath = '/home/jerome/dev/data/correctedCharacterisation/' #'/home/jerome/dev/experiments/beamPolarisation13/data/' #'/home/jerome/dev/data/sourceNdBeam/'
    
    files = ['intensityAfterMask.tif'] # ['intensityAtExitAp.tif', 'intensityAtM3.tif', 'intensityAtExitSlits.tif']#, 'atBDA_200yintensity.tif'] #
    labels = ['Exit Aperture Intensity', 'M3 Intensity', 'Exit Slits Intensity']
    res = [(2.5011765755127684e-09,2.426754715058574e-07)]
#        [(1.3683879929232588e-05, 1.4105451618857176e-05),
#           (1.3806530986264533e-05, 1.4150856529979121e-05),
#           (1.5250285651236968e-05, 9.668362831086895e-06)]
#           (3.3452615124385716e-07, 6.074644954894064e-06)]

    fileType = 0      # 0 for tiff file, 1 for pickle file
    
    print(len(files))
    
    savepath = [dirPath + files[i][0:len(str(files[i])) - 4] + 'SE.png' for i in range(0,len(files))] 
    
    if fileType == 0:
        T = [tifffile.imread(dirPath + f) for f in files]
    elif fileType == 1:
        T = [pickle.load(open(dirPath + f, 'rb')) for f in files]
    else:
        pass
    
    Tnew = [resample(t, fx=1,fy=1) for t in T] 
    
    print(np.shape(T[0]))
    print(np.shape(Tnew[0]))
    
    
    for i, t in enumerate(Tnew):
        plotTwoD(t,
                dx = res[i][0],
                dy = res[i][1],
                sF = 1e3,
                describe = True,
                title= None, #labels[i],
                xLabel= 'x-position [mm]',
                yLabel= 'y-position [mm]',
                aspct = 65,
                colour = 'gray',
                cbarLabel= 'Intensity [ph/s/.1\%bw/mm²]',
                savePath = savepath[i] )#'Intensity [ph/s/.1%bw/mm²]')

def testPlot1D():
    dirPath = '/home/jerome/dev/data/correctedCoherence/coherence' #'/home/jerome/dev/experiments/beamPolarisation13/data/' #'/home/jerome/dev/data/sourceNdBeam/'
    
    files =  ['NormalisedIx.pkl','xProf.pkl']
    labels = ['normalised intensity (y=0)', 'horizontal coherence']
    res = [3.3452615124385716e-07]
    
    savePath = None #'/home/jerome/Documents/MASTERS/Figures/plots/'

    picks = [pickle.load(open(dirPath + f, 'rb')) for f in files]
    
    print(np.shape(picks))
    plotOneD(picks, res[0], sF = 1e3,
             describe = True,
             split = None,
             title = None,
             labels = labels,
             xLabel='Position [mm]',
             yLabel='Horizontal Coherence',
             aspct = 5000,
             savePath= '/home/jerome/dev/data/correctedCoherence/CoherenceProfileXcut.png')


if __name__ == "__main__":
    testPlot2D()
#    testPlot1D()
    
