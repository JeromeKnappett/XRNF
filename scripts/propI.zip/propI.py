#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug  3 14:57:45 2021

@author: jerome
"""

import numpy as np
from math import log10, floor

import matplotlib.pyplot as plt
import pylab

plt.style.use(['science','no-latex']) # 'ieee', 
pylab.rcParams['figure.figsize'] = (10.0, 8.0)

def round_sig(x, sig=2):
    if x != 0:
        return round(x, sig-int(floor(log10(abs(x))))-1)
    else:
        return x

dirPath = '/home/jerome/dev/experiments/beamCoherence2/data/' 

trials = ['200e/','10000e/', '120e_250ir/']
mePR = 'res_int_pr_me.dat'

#data = 'res_int_pr_me.dat' 

#for p in dirPath:
#    nx = str(np.loadtxt(p + 'res_int_pr_me.dat', dtype=str, comments=None, skiprows=6, max_rows=1, usecols=(0)))[1:]#[1:3]
#    ny = str(np.loadtxt(p + 'res_int_pr_me.dat', dtype=str, comments=None, skiprows=9, max_rows=1, usecols=(0)))[1:]#[1:3]
#    print("Initial resolution (x,y): {}".format((nx,ny)))
#    I = np.reshape(np.loadtxt(p + 'res_int_pr_me.dat',skiprows=10), (int(nx),int(ny)))         # Initial intensity     

for t in trials:
    name = t[0:len(str(t))-1]
    print("Analysing trial: {}".format(name))
    nx = str(np.loadtxt(dirPath+t+mePR, dtype=str, comments=None, skiprows=6, max_rows=1, usecols=(0)))[1:]#[1:3]
    ny = str(np.loadtxt(dirPath+t+mePR, dtype=str, comments=None, skiprows=9, max_rows=1, usecols=(0)))[1:]#[1:3]
    xMin = str(np.loadtxt(dirPath+t+mePR, dtype=str, comments=None, skiprows=4, max_rows=1, usecols=(0)))[1:]#[1:3]
    xMax = str(np.loadtxt(dirPath+t+mePR, dtype=str, comments=None, skiprows=5, max_rows=1, usecols=(0)))[1:]#[1:3]
    rx = float(xMax)-float(xMin)
    dx = np.divide(rx,float(nx))
    yMin = str(np.loadtxt(dirPath+t+mePR, dtype=str, comments=None, skiprows=7, max_rows=1, usecols=(0)))[1:]#[1:3]
    yMax = str(np.loadtxt(dirPath+t+mePR, dtype=str, comments=None, skiprows=8, max_rows=1, usecols=(0)))[1:]#[1:3]
    ry = float(yMax)-float(yMin)
    dy = np.divide(ry,float(ny))
    
    numC = int(str(np.loadtxt(dirPath+t+mePR, dtype=str, comments=None, skiprows=10, max_rows=1, usecols=(0)))[1:])#[1:3]
    
    print("Resolution (x,y): {}".format((nx,ny)))
    print("xRange: {}".format(rx))
    print("xMax: {}".format(xMax))
    print("xMin: {}".format(xMin))
    print("yRange: {}".format(rx))
    print("yMax: {}".format(xMax))
    print("yMin: {}".format(xMin))
    print("Dx, Dy : {}".format((dx,dy)))
    
    I = np.reshape(np.loadtxt(dirPath+t+mePR,skiprows=10), (numC, int(ny),int(nx)))         # Propagated multi-electron intensity
    Iflat = I.flatten()
    
#    plt.plot(Iflat)
#    plt.show()
          
    """ Creating array of custom tick markers for plotting """
    sF = 1 #e6
    tickAx = [round_sig(-rx*sF/2),
              round_sig(-rx*sF/4),
              0,
              round_sig(rx*sF/4),
              round_sig(rx*sF/2)
              ]
    tickAy = [round_sig(-ry*sF/2),
              round_sig(-ry*sF/4),
              0,
              round_sig(ry*sF/4),
              round_sig(ry*sF/2)]
    
    
    if numC > 1:
        I1 = abs(I[0,:,:])
        I2 = abs(I[1,:,:])
        I3 = abs(I[2,:,:])
        I4 = abs(I[3,:,:])
    
        plt.imshow(I1)
        plt.title("I - component 1: {}".format(name))
        plt.show()
        
        fig, axs = plt.subplots(2, 2)
        #plt.clf()
        #plt.close()
        axs[0,0].imshow(I1)
        #plt.xticks(np.arange(0,float(nx)+1,float(nx)/4),tickAx)
        #plt.yticks(np.arange(0,float(ny)+1,float(ny)/4),tickAy)
        #plt.xlabel("position [m]") # [\u03bcm]")
        #plt.xlabel("position [m]") # [\u03bcm]")
        axs[0,0].set_title("C #1") #Multi-Electron Intensity")
        axs[1,0].imshow(I2)
        axs[1,0].set_title("C #2")
        axs[0,1].imshow(I3)
        axs[0,1].set_title("C #3")
        axs[1,1].imshow(I4)
        axs[1,1].set_title("C #4")
        #plt.colorbar()
        #plt.savefig(dirPath + "plots/" + "intensity" + pk[0:len(str(pk))-3] + ".png")
        #print("Saving intensity plot to: {}".format("plots/" + "intensity" + pk[0:len(str(pk))-3] + ".png"))
        plt.show()
        #plt.clf()
        #plt.close()
    else:
        plt.imshow(I[0,:,:])
        plt.title("Multi-electron intensity: ".format(name))
        plt.colorbar()
        plt.show()
    
    
    
    
    
    try:
        ix = str(np.loadtxt(dirPath + t + 'res_int_se.dat', dtype=str, comments=None, skiprows=6, max_rows=1, usecols=(0)))[1:4]#[1:3]
        iy = str(np.loadtxt(dirPath + t + 'res_int_se.dat', dtype=str, comments=None, skiprows=9, max_rows=1, usecols=(0)))[1:4]#[1:3]
        print("Initial resolution (x,y): {}".format((ix,iy)))
        I0 = np.reshape(np.loadtxt(dirPath + t + 'res_int_se.dat',skiprows=10), (int(ix),int(iy)))         # Initial intensity     
    except OSError:
        print("No initial intensity file found...")
    except ValueError:
        print("Unexpected initial dimensions - Initial intensity file could not be reshaped")
        pass
    #try:
    #    I = np.reshape(np.loadtxt(dirPath + 'res_int_pr_me.dat',skiprows=11), (nx,ny))          # Propagated intensity
    #except OSError:
    #    print("No propagated intensity file found...")
    #except ValueError:
    #    print("Unexpected initial dimensions - Propagated intensity file could not be reshaped")
    #    pass
    try:
        cX = np.reshape(np.loadtxt(dirPath + t + 'res_int_pr_me_dcx.dat',skiprows=11), (int(nx),int(nx)))     # Horizontal coherence
        cY = np.reshape(np.loadtxt(dirPath + t + 'res_int_pr_me_dcy.dat',skiprows=11), (int(ny),int(ny)))     # Vertical coherence    
        dCx = np.diagonal(np.squeeze(cX))
        dCy = np.diagonal(np.squeeze(cY))
    except OSError:
        print("No coherence files found...")
    except ValueError:
        print("Unexpected initial dimensions - Coherence files could not be reshaped")
        pass
    try:
        miX = np.reshape(np.loadtxt(dirPath + t + 'res_int_pr_me_mix.dat',skiprows=11), (int(nx),int(nx),2))  # Horizontal mutual intensity
        miY = np.reshape(np.loadtxt(dirPath + t + 'res_int_pr_me_miy.dat',skiprows=11), (int(ny),int(ny),2)) # Vertical mutual intensity
    except OSError:
        print("No mutual intensity files found...")
    except ValueError:
        print("Unexpected initial dimensions - Mutual intensity files could not be reshaped")
        pass
    
    
    
    """ Plotting intensity, coherence """
    try:
        plt.clf()
        plt.close()
        plt.imshow(I0)
        plt.xticks(np.arange(0,nx+1,nx/4),tickAx)
        plt.yticks(np.arange(0,ny+1,ny/4),tickAy)
        plt.xlabel("position [m]") # [\u03bcm]")
        plt.xlabel("position [m]") # [\u03bcm]")
        plt.title("Initial intensity, : " + name)
        plt.colorbar()
    #    plt.savefig(dirPath + "plots/" + "initialintensity" + pk[0:len(str(pk))-3] + ".png")
    #    print("Saving initial intensity plot to: {}".format("plots/" + "initialintensity" + pk[0:len(str(pk))-3] + ".png"))
        plt.show()
        plt.clf()
        plt.close()
    except NameError:
        print("No initial intensity file...")
    except TypeError:
        print("... initial intensity file may be wrong dimensions")
        pass
    
    try:
        plt.clf()
        plt.close()
        plt.imshow(I)
        plt.xticks(np.arange(0,nx+1,nx/4),tickAx)
        plt.yticks(np.arange(0,ny+1,ny/4),tickAy)
        plt.xlabel("position [m]") # [\u03bcm]")
        plt.xlabel("position [m]") # [\u03bcm]")
        plt.title("Intensity, e =" + name)
        plt.colorbar()
    #    plt.savefig(dirPath + "plots/" + "intensity" + pk[0:len(str(pk))-3] + ".png")
    #    print("Saving intensity plot to: {}".format("plots/" + "intensity" + pk[0:len(str(pk))-3] + ".png"))
        plt.show()
        plt.clf()
        plt.close()
    except NameError:
        print("No propagated intensity file...")
    except TypeError:
        print("... propagated intensity file may be wrong dimensions")
        pass
    
    try:
        plt.imshow(cX)
        plt.title("Horizontal Coherence, e =" + name)
        plt.colorbar()
    #    plt.savefig(dirPath + "plots/" + "coherenceHor" + pk[0:len(str(pk))-3] + ".png")
    #    print("Saving horizontal coherence plot to: {}".format("plots/" + "coherenceHor" + pk[0:len(str(pk))-3] + ".png"))
        plt.show()
        plt.clf()
        plt.close()
        
    
        plt.plot(cX[:,int(int(nx)/2)], label="vertical")#, '.', markersize = 1, label="vertical")
        plt.plot(cX[int(int(nx)/2),:], label="horizontal")#, '.', markersize = 1, label="horizontal")
        plt.plot(np.diagonal(np.squeeze(cX)), label="diagonal")  #, '.', markersize = 1, label="diagonal")   
        plt.plot((I[0,int(int(ny)/2),:]/np.max(I[0,int(int(ny)/2),:])), label="intensity")#, '.', markersize = 1, label="intensity")
        plt.xticks(np.arange(0,int(nx)+1,int(nx)/4),tickAx)
        plt.xlabel("position [m]") # [\u03bcm]")
        plt.title("Horizontal Coherence (cuts): " + name)
        plt.legend()
    #    plt.savefig(dirPath + "plots/" + "coherenceHorCuts" + pk[0:len(str(pk))-3] + ".png")
    #    print("Saving horizontal coherence cuts plot to: {}".format("plots/" + "coherenceHorCuts" + pk[0:len(str(pk))-3] + ".png"))
        plt.show()
        plt.clf()
        plt.close()
        
        plt.imshow(cY)
        plt.title("Vertical Coherence, : " + name)
        plt.colorbar()
    #    plt.savefig(dirPath + "plots/" + "coherenceVer" + pk[0:len(str(pk))-3] + ".png")
    #    print("Saving vertical coherence plot to: {}".format("plots/" + "coherenceVer" + pk[0:len(str(pk))-3] + ".png"))
        plt.show()
        plt.clf()
        plt.close()
    
        
        plt.plot(cY[:,int(int(ny)/2)], label="vertical")#, '.', markersize = 1, label="vertical")
        plt.plot(cY[int(int(ny)/2),:], label="horizontal")#, '.', markersize = 1, label="horizontal")
        plt.plot(np.diagonal(np.squeeze(cY)), label="diagonal")   #, '.', markersize = 1, label="diagonal")   
        plt.plot((I[0,:,int(int(nx)/2)]/np.max(I[0,:,int(int(nx)/2)])), label="intensity")#, '.', markersize = 1, label="intensity")
        plt.xticks(np.arange(0,int(ny)+1,int(ny)/4),tickAy)
        plt.xlabel("position [m]") # [\u03bcm]")
        plt.title("Vertical Coherence (cuts), : " + name)
        plt.legend()
    #    plt.savefig(dirPath + "plots/" + "coherenceHorCuts" + pk[0:len(str(pk))-3] + ".png")
    #    print("Saving horizontal coherence cuts plot to: {}".format("plots/" + "coherenceHorCuts" + pk[0:len(str(pk))-3] + ".png"))
        plt.show()
        plt.clf()
        plt.close()
    #    plt.clf()
    #    plt.close()
#        clX, clY = wfCoherence.getCoherenceLength(dCx, dCy, 0.7, dirPath + "plots/" + "coherenceLen" + name + ".png")
#        print("Horizontal Coherence Length [m]: {}".format(abs(clX*dx)))
#        print("Vertical Coherence Length [m]: {}".format(abs(clY*dy)))
#        clx.append(abs(clX*dx))
    #    cly.append(abs(clY*dy))
    #    plt.clf()
    #    plt.close()
    except NameError:
        print("No coherence files...")
    except TypeError:
        print("... coherence files may be wrong dimensions")
        pass
    
    try:
        plt.close()
        plt.clf()
        fig, axs = plt.subplots(2, 3)
        axs[0,0].imshow(miX[:,:,0])
        axs[0,0].set_title("J - Horizontal (1)")
        axs[0,1].imshow(miX[:,:,1])
        axs[0,1].set_title("J - Horizontal (2)")
        axs[0,2].imshow(miX.mean(2))
        axs[0,2].set_title("J - Horizontal (mean)")
        axs[1,0].imshow(miX[:,:,0]/np.max(I))
        axs[1,0].set_title("J (1) - Normalised to I")
        axs[1,1].imshow(miX[:,:,1]/np.max(I))
        axs[1,1].set_title("J (2) - Normalised to I")
        axs[1,2].imshow(miX.mean(2)/np.max(I))
        axs[1,2].set_title("J (mean) - Normalised to I")
    #    print("Saving horizontal mutual intensity (J) plots to: {}".format(dirPath + "plots/" + "mutualIntensityHor" + pk[0:len(str(pk))-3] + ".png"))
    #    plt.savefig(dirPath + "plots/" + "mutualIntensityHor" + pk[0:len(str(pk))-3] + ".png")
        plt.show()
        plt.close()
        plt.clf()
            
        plt.close()
        plt.clf()
        fig, axs = plt.subplots(2, 3)
        axs[0,0].imshow(miY[:,:,0])
        axs[0,0].set_title("J - Vertical (1)")
        axs[0,1].imshow(miY[:,:,1])
        axs[0,1].set_title("J - Vertical (2)")
        axs[0,2].imshow(miY.mean(2))
        axs[0,2].set_title("J - Vertical (mean)")
        axs[1,0].imshow(miY[:,:,0]/np.max(I))
        axs[1,0].set_title("J (1) - Normalised to I")
        axs[1,1].imshow(miY[:,:,1]/np.max(I))
        axs[1,1].set_title("J (2) - Normalised to I")
        axs[1,2].imshow(miY.mean(2)/np.max(I))
        axs[1,2].set_title("J (mean) - Normalised to I")
    #    print("Saving vertical mutual intensity (J) plots to: {}".format(dirPath + "plots/" + "mutualIntensityVer" + pk[0:len(str(pk))-3] + ".png"))
    #    plt.savefig(dirPath + "plots/" + "mutualIntensityVer" + pk[0:len(str(pk))-3] + ".png")
        plt.show()
        plt.close()
        plt.clf()
    except NameError:
        print("No mutual intensity files...")
    except TypeError:
        print("... MI files may be wrong dimensions")
        pass